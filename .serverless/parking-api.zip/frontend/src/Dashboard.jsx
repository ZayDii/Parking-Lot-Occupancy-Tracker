// src/Dashboard.jsx
import React, { useEffect, useMemo, useState } from "react";
import { getSnapshot, getForecast, getStatus } from "./api";

const LOT_ID = "96N";
const POLL_MS = 5000;

function fmtETDateTime(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  const tz = 'America/New_York';

  const date = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, year: 'numeric', month: 'short', day: '2-digit'
  }).format(d);

  const time = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hour: 'numeric', minute: '2-digit', hour12: true
  }).format(d);

  const abbr = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, timeZoneName: 'short'
  }).formatToParts(d).find(p => p.type === 'timeZoneName')?.value || 'ET';

  return { date, time, abbr }; // e.g. { date: "Sep 02, 2025", time: "10:20 PM", abbr: "EDT" }
}

export default function Dashboard() {
  const [snap, setSnap] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [status, setStatus] = useState(null);
  const [error, setError] = useState("");
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [justRefreshed, setJustRefreshed] = useState(false);


  async function refresh(manual = false) {
  if (manual && isRefreshing) return;      // prevent double-click spams
  if (manual) setIsRefreshing(true);

  let ok = false;
  try {
    const [s, f, st] = await Promise.all([
      getSnapshot(LOT_ID),
      getForecast(LOT_ID, 12),
      getStatus(),
    ]);
    setSnap(s);
    setForecast(f.points || []);
    setStatus(st);
    setError("");
    ok = true;
  } catch {
    setError("Backend unavailable or no data yet.");
  } finally {
    if (manual) {
      setIsRefreshing(false);
      if (ok) {
        setJustRefreshed(true);
        setTimeout(() => setJustRefreshed(false), 900);
      }
    }
  }
}


  useEffect(() => {
    refresh(false);
    const id = setInterval(() => refresh(false), POLL_MS);
    return () => clearInterval(id);
}, []);


  const pct = useMemo(
    () => (snap ? Math.round(snap.occupancy_rate * 100) : 0),
    [snap]
    
  );
const updatedET = snap?.ts_iso ? fmtETDateTime(snap.ts_iso) : null;
const apiOk = Boolean(status?.api_ok ?? true);
const camsOk = Number(status?.cameras_online) > 0;
const edgeAgeMin = status?.edge_last_seen_iso
  ? Math.floor((Date.now() - Date.parse(status.edge_last_seen_iso)) / 60000)
  : Infinity;
const edgeClass = !status?.edge_last_seen_iso ? "bad" : edgeAgeMin > 15 ? "warn" : "ok";

  return (
    <section className="container">
      {/* Header uses the responsive toolbar pattern */}
      <header className="header toolbar" style={{ marginBottom: 12 }}>
        <div>
          <h2 className="h2" style={{ margin: 0 }}>Dashboard</h2>
          <p className="subtle" style={{ margin: "4px 0 0" }}>
            Lot: <b>{LOT_ID}</b>
          </p>
        </div>
        <div className="row">
         <button
  className={`btn btn-primary btn-lg ${isRefreshing ? 'is-loading' : ''}`}
  onClick={() => refresh(true)}
  disabled={isRefreshing}
  aria-busy={isRefreshing}
  title={isRefreshing ? 'Refreshing…' : 'Refresh now'}
>
  {/* Use your favicon here; .svg/.png/.ico all fine */}
  <img className="icon-img" src="/arrow.png" alt="" />

  <span className="btn-label">
    {isRefreshing ? 'Refreshing…' : justRefreshed ? 'Refreshed' : 'Refresh'}
  </span>
</button>


        </div>
      </header>

      {error && (
        <p style={{ color: "crimson", marginBottom: 16 }}>{error}</p>
      )}

      {/* Responsive grid: 1 col on mobile, 2 on small tablets, 3 on desktop */}
      <section className="grid">
        {/* Card 1 — Now */}
        <Card title="Now">
          {snap ? (
            <div className="now-grid">
              <Gauge percent={pct} />
              <div>
                <KV 
                  label="Occupied"
                  value={<><b>{snap.occupied_count}</b> / {snap.total_spots}</>}
                  stack
                />
                <Progress percent={pct} />
                <div className="updated">
  <span className="updated-label">Updated:</span>
  {updatedET ? (
    <span className="mono">
      {updatedET.date}<br/>
      {updatedET.time} <span className="tz">{updatedET.abbr}</span>
    </span>
  ) : '—'}
</div>

              </div>
            </div>
          ) : (
            <Skeleton lines={4} />
          )}
        </Card>

        {/* Card 2 — Next 12 hours */}
        <Card title="Next 12 hours">
  {forecast.length ? (
    <div className="media">
      <MiniBars data={forecast} labelSize={14} /> {/* try 15 or 16 if you want it louder */}
    </div>
  ) : (
    <Skeleton lines={6} />
  )}
</Card>

        {/* Card 3 — System */}
        <Card title="System">
          {status ? (
            <div style={{ display: "grid", gap: 8 }}>
              <KV label="Uptime" value={fmtUptime(status.service_uptime_s)} />
              <KV label="Cameras online" value={String(status.cameras_online)} />
              {(() => {
  const et = status?.edge_last_seen_iso ? fmtETDateTime(status.edge_last_seen_iso) : null;
  return (
    <KV
      label="Edge last seen"
      value={
        et ? (
          <div className="kv-stack">
            <div className="mono">{et.date}</div>
            <div className="mono">
  {et.time} <span className="tz">{et.abbr.replace('GMT','ET')}</span></div>
          </div>
        ) : "—"
      }
    />
  );
})()}
              <div className="badges">
  <span className={`badge ${apiOk ? "ok" : "bad"}`}><span className="dot" />API</span>
  <span className={`badge ${camsOk ? "ok" : "bad"}`}><span className="dot" />Cameras</span>
  <span className={`badge ${edgeClass}`}><span className="dot" />Edge</span>
</div>
            </div>
          ) : (
            <Skeleton lines={4} />
          )}
        </Card>
      </section>
    </section>
  );
}

/* ---------- UI bits ---------- */

function Card({ title, children }) {
  return (
    <div className="card">
      <h3 style={{ marginTop: 0, fontSize: 16 }}>{title}</h3>
      {children}
    </div>
  );
}

function KV({ label, value, right, stack = false }) {
  if (stack) {
    return (
      <div className="kv kv-stackrow">
        <span className="label">{label}</span>
        <span className="value">{value}{right ?? null}</span>
      </div>
    );
  }
  return (
    <div className="kv" style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
      <span className="label" style={{ color: "var(--muted)" }}>{label}</span>
      <span className="value">{value}{right ?? null}</span>
    </div>
  );
}

function Progress({ percent }) {
  return (
    <div
      className="progress"
      aria-label="Occupancy progress"
      style={{
        marginTop: 8,
        width: "100%",
        height: 10,
        borderRadius: 999,
        background: "rgba(255,255,255,0.08)",
        overflow: "hidden",
        border: "1px solid var(--border)",
      }}
    >
      <span
        style={{
          display: "block",
          width: `${percent}%`,
          height: "100%",
          background: "var(--accent)",
        }}
      />
    </div>
  );
}

function Skeleton({ lines = 3 }) {
  return (
    <div style={{ display: "grid", gap: 8 }}>
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className="skel"
          style={{
            height: 12,
            borderRadius: 8,
            background:
              "linear-gradient(90deg, rgba(255,255,255,0.04), rgba(255,255,255,0.12), rgba(255,255,255,0.04))",
            backgroundSize: "200% 100%",
            animation: "shimmer 1.2s linear infinite",
          }}
        />
      ))}
    </div>
  );
}

function Gauge({ percent }) {
  const clamped = Math.min(100, Math.max(0, percent));
  const deg = clamped * 3.6;
  return (
    <div
      className="gauge-ring"
      style={{
        borderRadius: "50%",
        background: `conic-gradient(var(--accent) ${deg}deg, #e5e7eb 0deg)`,
        display: "grid",
        placeItems: "center",
      }}
    >
      <div
        className="gauge-inner"
        style={{
          borderRadius: "50%",
          background: "var(--card)",
          display: "grid",
          placeItems: "center",
          border: "1px solid var(--border)",
        }}
      >
        <div className="gauge-num" style={{ fontWeight: 700, fontSize: 20 }}>
          {clamped}%
        </div>
        <div className="gauge-sub" style={{ fontSize: 12, opacity: 0.7 }}>
          full
        </div>
      </div>
    </div>
  );
}

function MiniBars({
  data,
  labelSize = 14,         // font size for both lines
  tickEvery = 3,          // show every Nth tick
  tickOffset = 20,        // vertical gap from the x-axis to first line
  labelColor = "#cfd6e4", // time color
  subLabelColor = "#b3bfd0", // AM/PM color
  labelShiftX = 10,        // ← NEW: nudge x-axis labels horizontally (px). +right, -left
  yLabelShiftX = 0        // ← NEW: nudge right-side % labels (px)
}) {
  const width = 420, height = 200;
  const pad = { l: 24, r: 84, t: 14, b: Math.max(56, tickOffset + labelSize * 2 + 8) };

  const w = width - pad.l - pad.r;
  const h = height - pad.t - pad.b;
  const step = w / data.length;
  const bw = Math.max(6, Math.floor(step) - 6);
  const axisRightX = pad.l + w;

  const toET = (iso) => {
    const d = new Date(iso);
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/New_York",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    }).formatToParts(d);
    const hh = parts.find(p => p.type === "hour")?.value ?? "";
    const mm = parts.find(p => p.type === "minute")?.value ?? "";
    const ampm = (parts.find(p => p.type === "dayPeriod")?.value ?? "").toUpperCase();
    return { hhmm: `${hh}:${mm}`, ampm };
  };

  return (
    <svg
      role="img"
      aria-label="Forecast"
      viewBox={`0 0 ${width} ${height}`}
      width="100%"
      height="100%"
      preserveAspectRatio="xMidYMid meet"
    >
      {/* X-axis */}
      <line
        x1={pad.l}
        y1={pad.t + h}
        x2={axisRightX}
        y2={pad.t + h}
        stroke="#e5e7eb"
        strokeWidth="1.2"
        shapeRendering="crispEdges"
      />

      {/* Bars + ticks */}
      {data.map((pt, i) => {
        const slotCenterX = pad.l + (i + 0.5) * step;
        const barX = slotCenterX - bw / 2;
        const v = Math.max(0, Math.min(1, pt.expected_occupancy_rate));
        const barH = v * h;
        const y = pad.t + (h - barH);
        const { hhmm, ampm } = toET(pt.ts_iso);

        // label x position (nudged)
        const lx = slotCenterX + labelShiftX;

        return (
          <g key={pt.ts_iso}>
            <rect x={barX} y={y} width={bw} height={barH} rx="4" ry="4" fill="var(--accent)" opacity="0.9" />
            {i % tickEvery === 0 && (
              <text
                x={lx}
                y={pad.t + h + tickOffset}
                fontSize={labelSize}
                textAnchor="middle"
                fontWeight="600"
                fill={labelColor}
              >
                <tspan x={lx} dy="0">{hhmm}</tspan>
                <tspan x={lx} dy={labelSize} fill={subLabelColor}>{ampm}</tspan>
              </text>
            )}
          </g>
        );
      })}

      {/* Y-axis labels (right gutter) */}
      {[0, 25, 50, 75, 100].map((p) => {
        const y = pad.t + (h - (p / 100) * h);
        const x = axisRightX + 8 + yLabelShiftX;   // ← nudged
        return (
          <text
            key={p}
            x={x}
            y={y}
            fontSize={labelSize}
            fill="#cfd6e4"
            textAnchor="start"
            dominantBaseline="middle"
            fontWeight="600"
          >
            {p}%
          </text>
        );
      })}
    </svg>
  );
}





/* ---------- helpers ---------- */
function fmtUptime(s) {
  const d = Math.floor(s / 86400),
    h = Math.floor((s % 86400) / 3600),
    m = Math.floor((s % 3600) / 60);
  if (d) return `${d}d ${h}h ${m}m`;
  if (h) return `${h}h ${m}m`;
  return `${m}m`;
}
